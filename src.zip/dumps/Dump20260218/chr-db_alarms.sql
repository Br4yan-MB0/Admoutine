CREATE DATABASE  IF NOT EXISTS `chr-db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `chr-db`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chr-db
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarms`
--

DROP TABLE IF EXISTS `alarms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alarms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `alarm_time` datetime NOT NULL,
  `type` varchar(50) DEFAULT 'general',
  `reference_id` int DEFAULT NULL,
  `triggered` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `alarms_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarms`
--

LOCK TABLES `alarms` WRITE;
/*!40000 ALTER TABLE `alarms` DISABLE KEYS */;
INSERT INTO `alarms` VALUES (1,2,'2026-02-12 07:14:00','routine',3,1,'2026-02-16 07:14:03'),(2,2,'2026-02-16 07:19:00','routine',4,1,'2026-02-16 07:19:03'),(3,2,'2026-02-16 08:27:00','routine',5,1,'2026-02-16 08:27:48'),(4,2,'2026-02-16 08:53:00','routine',8,1,'2026-02-16 08:56:44'),(5,2,'2026-02-16 10:34:00','routine',9,1,'2026-02-16 10:32:17'),(6,2,'2026-02-16 10:33:00','routine',10,1,'2026-02-16 10:32:46'),(7,2,'2026-02-16 10:41:00','routine',11,1,'2026-02-16 10:40:32'),(8,2,'2026-02-16 10:50:00','routine',12,1,'2026-02-16 10:49:31'),(9,2,'2026-02-16 10:53:00','routine',13,1,'2026-02-16 10:52:48'),(10,2,'2026-02-16 11:02:00','routine',14,1,'2026-02-16 11:01:24'),(11,2,'2026-02-16 11:05:00','routine',15,1,'2026-02-16 11:04:12'),(12,2,'2026-02-16 11:07:00','routine',16,1,'2026-02-16 11:06:06'),(13,2,'2026-02-16 11:09:00','routine',17,1,'2026-02-16 11:07:25'),(14,2,'2026-02-18 05:21:00','routine',33,1,'2026-02-18 05:20:00'),(15,2,'2026-02-18 05:22:00','routine',34,1,'2026-02-18 05:21:59'),(16,2,'2026-02-18 05:48:00','routine',35,1,'2026-02-18 05:47:49'),(17,2,'2026-02-18 05:49:00','routine',36,1,'2026-02-18 05:48:31'),(18,2,'2026-02-18 05:50:00','routine',37,1,'2026-02-18 05:49:38'),(19,2,'2026-02-18 05:50:00','routine',38,1,'2026-02-18 05:49:56'),(20,2,'2026-02-18 05:52:00','routine',39,1,'2026-02-18 05:52:38'),(21,2,'2026-02-18 06:26:00','routine',40,1,'2026-02-18 06:25:13');
/*!40000 ALTER TABLE `alarms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-18  8:27:12
